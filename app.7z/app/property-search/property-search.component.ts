import { City } from './../Shared/property.model';
import { Response } from '@angular/http';
import { PropertyService } from 'src/app/Shared/property-details.service';
import { startWith, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { filter } from "rxjs/internal/operators/filter";

@Component({
  selector: 'app-property-search',
  templateUrl: './property-search.component.html',
  styleUrls: ['./property-search.component.css']
})
export class PropertySearchComponent implements OnInit 
{
  constructor(private router: Router,private propertyservice:PropertyService) { }
  myControl = new FormControl();
  options = new Array<string>();
  filteredOptions: Observable<string[]>;

  ngOnInit() {
    this.propertyservice.getCityList().subscribe(data => {
      this.propertyservice.options = data as City[];
      this.propertyservice.options.forEach(element => {
        this.options.push(element.City_name);
      });
      
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
        startWith(''),
        map(value => this._filter(value))
        );   
    })
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

 onDone(valuei: string) {
    this.router.navigate(['/property-lists', {valuei}]);
  }
}







