import { Property } from './../Shared/property.model';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/Shared/property-details.service";

@Component({
  selector: 'app-property-details',
  templateUrl: './property-details.component.html',
  styleUrls: ['./property-details.component.css']
})
export class PropertyDetailsComponent implements OnInit {
  property = new Property();
  constructor(private propertyservice: PropertyService, private route: ActivatedRoute) { }

  ngOnInit(): void {
  this.route.params.subscribe(params => { this.propertyservice.Pid= params['val'] });
  this.propertyservice.getProperties(this.propertyservice.Pid).subscribe(data => {
    this.propertyservice.Selectedproperty = data as Property
  });
  }
  
}