import { map } from 'rxjs/operators';
import { Property, City } from './property.model';
import { Injectable } from '@angular/core';
//import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class PropertyService {
  Selectedproperty = new Property();
  options:City[]=[];
  Place :string;
  CityNames : string[];
  PropertyList:Property[];
  Pid:number;
  constructor(private http: HttpClient) { }

  getCityList() : Observable<any>{
     
    return this.http.get('http://localhost:59207/api/PropertyDetails/GetCity');
  }

  getPropertyList(city:string) :Observable<any>
  {
    return this.http.get('http://localhost:59207/api/PropertyDetails/GetProperties?city='+city);
  }
  getProperties(id: number): Observable<any> {
    return this.http.get('http://localhost:59207/api/PropertyDetails/GetProperty?id='+ id);
  }
}
