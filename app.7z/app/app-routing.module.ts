import { PropertyDetailsComponent } from './property-details/property-details.component';
import { PropertyListsComponent } from './property-lists/property-lists.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'property-lists', component: PropertyListsComponent },
  { path: 'property-details', component: PropertyDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
