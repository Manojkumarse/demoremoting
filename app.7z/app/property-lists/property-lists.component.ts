import { Property } from './../Shared/property.model';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/Shared/property-details.service";

@Component({
  selector: 'app-property-lists',
  templateUrl: './property-lists.component.html',
  styleUrls: ['./property-lists.component.css']
})
export class PropertyListsComponent implements OnInit {
  
  constructor(private route: ActivatedRoute, private propertyservice: PropertyService) { 
  }
  ngOnInit():void {
   this.route.params.subscribe(params => { this.propertyservice.Place=params['valuei'] });
   this.propertyservice.getPropertyList(this.propertyservice.Place).subscribe(data => {
   this.propertyservice.PropertyList = data as Property[]});   
}
}
