import { HttpClientModule } from '@angular/common/http';
import { Http } from '@angular/http';


import { PropertyService } from 'src/app/Shared/property-details.service';
import { MatAutocompleteModule, MatFormFieldModule, MatInputModule, MatGridListModule, MatCardModule, MatMenuModule, MatIconModule, MatButtonModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PropertyDetailsComponent } from './property-details/property-details.component';
import { PropertyListsComponent } from './property-lists/property-lists.component';
import { PropertySearchComponent } from "src/app/property-search/property-search.component";
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { CardListComponent } from './property-lists/card-list/card-list.component';
import { FilterListComponent } from './property-lists/filter-list/filter-list.component';
import { LayoutModule } from "@angular/cdk/layout";
import { CommonModule } from "@angular/common";


@NgModule({
  declarations: [
    AppComponent,
    PropertySearchComponent,
    PropertyDetailsComponent,
    PropertyListsComponent,
    CardListComponent,
    FilterListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    HttpClientModule,
    CommonModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    LayoutModule
  ],
  providers: [PropertyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
