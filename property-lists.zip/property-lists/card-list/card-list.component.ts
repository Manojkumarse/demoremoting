import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/Shared/property-details.service";

@Component({
  selector: 'app-card-list',
  templateUrl: './card-list.component.html',
  styleUrls: ['./card-list.component.css']
})
export class CardListComponent implements OnInit {
  constructor(private propertyservice: PropertyService, private router: Router) { }
  ngOnInit(): void {  
  
}
  Oncomplete(val: number) {
    this.router.navigate(['/property-details', {val}]);
  }
}
